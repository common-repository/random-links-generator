<?php
/*
Plugin Name: Random Link Generator
Plugin URI: http://www.rehatched.com
Description: A small plugin that takes a separated comma list and outputs random links via shortcode(s)
Version: 1.0
Author: Rehatched Media
Author URI: http://www.rehatched.com
License: GPL2
*/

/*  Copyright 2013  Rehatched Media  (email : hello@rehatched.com)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License, version 2, as
    published by the Free Software Foundation.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

add_action('admin_menu', 'random_links_admin_actions');

function random_links_admin_actions()
{
    add_options_page('Random Links','Random Links','administrator','random_links','random_links');
}

register_activation_hook( __FILE__, 'random_links_activate' );

function random_links_activate() {
	add_option( 'random_links_count', '4' );
}

function random_links() {
    
	if(isset($_POST) && $_POST['action'] == "updatecount")
	{
		update_option('random_links_count', trim($_POST['random_links_count']));	
	}
	
	?>
    <h1><a href="http://www.wpcloudlayer.com">Premium Managed WordPress Hosting</a></h1>
<div class="wrap">
    <h2>Random Link Generator</h2>
    <form method="post">
    	<input name="action" type="hidden" value="updatecount" />
        <table class="form-table">
            <tr valign="top">
                <th scope="row">Number of Fields?</th>
                <td><input type="text" name="random_links_count" value="<?php echo get_option('random_links_count'); ?>" /></td>
            </tr>
        </table>
        <?php submit_button('Update Number of Fields'); ?>
    </form>
</div>
<?php
	if(isset($_POST) && $_POST['action'] == "updatelinks")
	{
		while($i <= get_option('random_links_count'))
		{
			update_option('linkgroup_id_'.$i, trim($_POST['linkgroup_id_'.$i]));
			$i++;
		}
	}
    ?>
    <hr>
<div class="wrap">
    <form method="post">
    	<input name="action" type="hidden" value="updatelinks" />
        <table class="form-table">
            <?php $i = 1 ?>
            <?php while($i <= get_option('random_links_count')) { ?>
            <tr valign="top">
                <th scope="row">Link Group <?php echo $i;?>: </th>
                <td><input type="text" name="linkgroup_id_<?php echo $i; ?>" value="<?php echo get_option('linkgroup_id_'.$i); ?>" /><br /><small>Shortcode: [random-links id=<?php echo $i;?>]</small></td>
                <?php $i++;?>
            </tr>
            <?php } ?>
        </table>
        <?php submit_button('Save Links'); ?>
    </form>
</div>
<?php }

//Shortcodes

function random_links_shortcode($atts)
{
    extract(shortcode_atts(array(
        'id'  =>  ''
    ), $atts));
	
	$links = explode(",",get_option('linkgroup_id_'.$id));
	
	$randkey = array_rand($links);
	
    return trim($links[$randkey]);
}

add_shortcode('random-links', 'random_links_shortcode');