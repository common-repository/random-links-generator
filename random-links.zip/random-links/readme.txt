=== Plugin Name ===
Contributors: WPCloudLayer
Donate link: http://www.wpcloudlayer.com
Tags: random links, rotating links
Requires at least: 3.0.1
Tested up to: 3.5
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin takes a comma separated list and outputs a shortcode designated from that list.  From there you can place
the shortcode anywhere in your theme and each time the page is loaded, a new link will be displayed.

== Description ==

This plugin takes a comma separated list and outputs a shortcode designated from that list.  From there you can place
the shortcode anywhere in your theme and each time the page is loaded, a new link will be displayed.

== Installation ==

1. Upload `random-links` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress


== Frequently Asked Questions ==

N/A

== Screenshots ==

1. http://rehatched.com/wordpress-plugin-random-links-generator

== Changelog ==

= 1.0 =
*First Version